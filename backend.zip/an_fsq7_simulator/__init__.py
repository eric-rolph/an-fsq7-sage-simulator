"""Component initialization."""
