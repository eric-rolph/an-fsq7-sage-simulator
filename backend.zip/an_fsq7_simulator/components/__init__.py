"""Component package initialization."""

from .status_bar import status_bar
