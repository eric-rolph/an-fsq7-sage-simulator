"""Fix sd_console.py to remove State Var issues"""
import re

# Read file
with open('an_fsq7_simulator/components_v2/sd_console.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix 1: Remove active state checks
content = re.sub(
    r'active=\([^)]*in active_[^)]+\)',
    'active=False',
    content
)

# Fix 2: Remove rx.State event handlers but keep the parameter
content = re.sub(
    r',\s*on_click=rx\.State\.[^,)]+(?=\s*(?:,|\)))',
    '',
    content
)

# Fix 3: Remove on_change rx.State handlers
content = re.sub(
    r',\s*on_change=rx\.State\.[^,)]+(?=\s*(?:,|\)))',
    '',
    content
)

# Fix 4: active_filters_display - replace list comprehension
old_display = r'''def active_filters_display\(filters: Set\[str\], overlays: Set\[str\]\) -> rx\.Component:
    """
    Status bar showing currently active filters and overlays
    """
    return rx\.box\(
        rx\.hstack\(
            # Active filters
            rx\.box\(
                rx\.text\("ACTIVE FILTERS:", font_weight="bold", color="#00ff00", font_size="0\.8rem"\),
                rx\.wrap\(
                    \*\[
                        rx\.badge\(f\.upper\(\), color_scheme="green", size="1"\)
                        for f in sorted\(filters\)
                    \] if filters else \[rx\.text\("NONE", color="#666666", font_size="0\.75rem"\)\],
                    spacing="1",
                \),
            \),
            
            rx\.divider\(orientation="vertical", height="30px"\),
            
            # Active overlays
            rx\.box\(
                rx\.text\("ACTIVE OVERLAYS:", font_weight="bold", color="#00ff00", font_size="0\.8rem"\),
                rx\.wrap\(
                    \*\[
                        rx\.badge\(o\.replace\("_", " "\)\.upper\(\), color_scheme="blue", size="1"\)
                        for o in sorted\(overlays\)
                    \] if overlays else \[rx\.text\("NONE", color="#666666", font_size="0\.75rem"\)\],
                    spacing="1",
                \),
            \),'''

new_display = '''def active_filters_display(filters: Set[str], overlays: Set[str]) -> rx.Component:
    """
    Status bar showing currently active filters and overlays
    Note: Simplified to avoid iterating over State Vars
    """
    return rx.box(
        rx.hstack(
            # Active filters
            rx.box(
                rx.text("ACTIVE FILTERS:", font_weight="bold", color="#00ff00", font_size="0.8rem"),
                rx.text("(Filters active - display coming soon)", color="#666666", font_size="0.75rem"),
            ),
            
            rx.divider(orientation="vertical", height="30px"),
            
            # Active overlays
            rx.box(
                rx.text("ACTIVE OVERLAYS:", font_weight="bold", color="#00ff00", font_size="0.8rem"),
                rx.text("(Overlays active - display coming soon)", color="#666666", font_size="0.75rem"),
            ),'''

content = re.sub(old_display, new_display, content, flags=re.DOTALL)

# Write back
with open('an_fsq7_simulator/components_v2/sd_console.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed sd_console.py")
