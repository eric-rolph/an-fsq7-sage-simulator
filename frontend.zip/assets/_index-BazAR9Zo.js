import{r as e}from"./rolldown-runtime-BJDU5wuE.js";import{A as t,j as n}from"./chunk-UIGDSWPH-C04fXvyt.js";import"./react-dom-D6ZpGae-.js";import{a as r,c as i,d as a,f as o,g as s,i as ee,l as c,m as l,n as u,o as d,r as f,s as p,x as m}from"./esm-CnXlpPlW.js";import"./reflex-env-By1RcMqa.js";import{n as h}from"./emotion-react.browser.esm-CqHwHMeh.js";var g=e(n());function _(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(p,{css:{minHeight:`1.5rem`},gap:`1`,wrap:`wrap`},Array.prototype.map.call(e.active_filters_rx_state_??[],(e,t)=>h(c,{color:`green`,key:t,size:`1`},e.toUpperCase())))}function v(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(p,{css:{minHeight:`1.5rem`},gap:`1`,wrap:`wrap`},Array.prototype.map.call(e.active_overlays_rx_state_??[],(e,t)=>h(c,{color:`blue`,key:t,size:`1`},e.replaceAll(`_`,` `).toUpperCase())))}function y(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`all`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`all`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`all`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`all`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`all`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S1 ALL`)}function b(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`friendly`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`friendly`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`friendly`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`friendly`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`friendly`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S2 FRIENDLY`)}function x(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`unknown`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`unknown`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`unknown`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`unknown`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`unknown`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S3 UNKNOWN`)}function S(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`hostile`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`hostile`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`hostile`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`hostile`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`hostile`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S4 HOSTILE`)}function C(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`missile`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`missile`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`missile`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`missile`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`missile`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S5 MISSILE`)}function w(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`bomber`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`bomber`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`bomber`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`bomber`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`bomber`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S6 BOMBER`)}function T(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`fighter`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`fighter`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`fighter`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`fighter`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`fighter`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S7 FIGHTER`)}function E(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`alt_low`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`alt_low`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`alt_low`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`alt_low`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`alt_low`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S8 ALT<10K`)}function D(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`alt_med`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`alt_med`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`alt_med`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`alt_med`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`alt_med`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S9 ALT 10K-30K`)}function O(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`alt_high`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`alt_high`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`alt_high`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`alt_high`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`alt_high`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S10 ALT>30K`)}function k(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`inbound`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`inbound`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`inbound`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`inbound`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`inbound`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S11 INBOUND`)}function A(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`outbound`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`outbound`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`outbound`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`outbound`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`outbound`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S12 OUTBOUND`)}function j(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_filter`,{filter_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_filters_rx_state_.includes(`loitering`)?`#003300`:`#001100`,color:e.active_filters_rx_state_.includes(`loitering`)?`#00ff00`:`#004400`,border:e.active_filters_rx_state_.includes(`loitering`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_filters_rx_state_.includes(`loitering`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_filters_rx_state_.includes(`loitering`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`1`},`S13 LOITERING`)}function M(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_overlay`,{overlay_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_overlays_rx_state_.includes(`flight_paths`)?`#003300`:`#001100`,color:e.active_overlays_rx_state_.includes(`flight_paths`)?`#00ff00`:`#004400`,border:e.active_overlays_rx_state_.includes(`flight_paths`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_overlays_rx_state_.includes(`flight_paths`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_overlays_rx_state_.includes(`flight_paths`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`2`},`S20 FLIGHT PATHS`)}function N(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_overlay`,{overlay_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_overlays_rx_state_.includes(`intercept_vectors`)?`#003300`:`#001100`,color:e.active_overlays_rx_state_.includes(`intercept_vectors`)?`#00ff00`:`#004400`,border:e.active_overlays_rx_state_.includes(`intercept_vectors`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_overlays_rx_state_.includes(`intercept_vectors`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_overlays_rx_state_.includes(`intercept_vectors`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`2`},`S21 INTERCEPTS`)}function P(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_overlay`,{overlay_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_overlays_rx_state_.includes(`range_rings`)?`#003300`:`#001100`,color:e.active_overlays_rx_state_.includes(`range_rings`)?`#00ff00`:`#004400`,border:e.active_overlays_rx_state_.includes(`range_rings`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_overlays_rx_state_.includes(`range_rings`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_overlays_rx_state_.includes(`range_rings`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`2`},`S22 RANGE RINGS`)}function F(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_overlay`,{overlay_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_overlays_rx_state_.includes(`callsigns`)?`#003300`:`#001100`,color:e.active_overlays_rx_state_.includes(`callsigns`)?`#00ff00`:`#004400`,border:e.active_overlays_rx_state_.includes(`callsigns`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_overlays_rx_state_.includes(`callsigns`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_overlays_rx_state_.includes(`callsigns`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`2`},`S23 CALLSIGNS`)}function I(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.toggle_overlay`,{overlay_name:{button:e?.button,buttons:e?.buttons,client_x:e?.clientX,client_y:e?.clientY,alt_key:e?.altKey,ctrl_key:e?.ctrlKey,meta_key:e?.metaKey,shift_key:e?.shiftKey}},{})],[e],{}),[t,m]);return h(d,{css:{background:e.active_overlays_rx_state_.includes(`coastlines`)?`#003300`:`#001100`,color:e.active_overlays_rx_state_.includes(`coastlines`)?`#00ff00`:`#004400`,border:e.active_overlays_rx_state_.includes(`coastlines`)?`2px solid #00ff00`:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:e.active_overlays_rx_state_.includes(`coastlines`)?`#005500`:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:e.active_overlays_rx_state_.includes(`coastlines`)?`0 0 10px rgba(0,255,0,0.3)`:`none`,transition:`all 0.2s`},onClick:r,size:`2`},`S24 COASTLINES`)}function L(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.pan_scope`,{direction:`up`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`↑`)}function R(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.pan_scope`,{direction:`left`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`←`)}function z(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.center_scope`,{},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`⊙`)}function B(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.pan_scope`,{direction:`right`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`→`)}function V(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.pan_scope`,{direction:`down`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`↓`)}function H(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.zoom_scope`,{direction:`out`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`−`)}function U(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.zoom_scope`,{direction:`in`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`+`)}function te(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.zoom_scope`,{direction:`fit`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`FIT`)}function W(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.rotate_scope`,{direction:`ccw`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`↶`)}function G(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.rotate_scope`,{direction:`reset`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`N`)}function K(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.rotate_scope`,{direction:`cw`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`2`},`↷`)}function q(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state),[t,n]=(0,g.useContext)(l),r=(0,g.useCallback)(e=>t([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.set_brightness_percent`,{percent:e},{})],[e],{}),[t,m]);return h(u,{color:`green`,css:{width:`100%`},defaultValue:[e.brightness_rx_state_*100],max:100,min:20,onValueChange:r,step:5,width:`100%`})}function J(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(a,{as:`p`,css:{color:`#00ff00`,fontSize:`1.5rem`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,textAlign:`center`}},(e.brightness_rx_state_*100).toLocaleString(`en-US`,(e=>({minimumFractionDigits:e,maximumFractionDigits:e}))(0)).replaceAll(`,`,``)+`%`)}function Y(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.set_brightness_preset`,{value:`dim`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`1`},`DIM`)}function X(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.set_brightness_preset`,{value:`med`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`1`},`MED`)}function Z(){let[e,t]=(0,g.useContext)(l),n=(0,g.useCallback)(t=>e([m(`reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state.set_brightness_preset`,{value:`bright`},{})],[t],{}),[e,m]);return h(d,{css:{background:`#001100`,color:`#004400`,border:`2px solid #003300`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`,"&:hover":{background:`#002200`,borderColor:`#00ff00`,color:`#00ff00`},boxShadow:`none`,transition:`all 0.2s`},onClick:n,size:`1`},`BRIGHT`)}function Q(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(i,{css:{width:(1-e.maintenance_rx_state_?.performance_penalty)*100+`%`,height:`100%`,background:1-e.maintenance_rx_state_?.performance_penalty>=.9?`#00ff00`:1-e.maintenance_rx_state_?.performance_penalty>=.7?`#88ff00`:1-e.maintenance_rx_state_?.performance_penalty>=.5?`#ffff00`:1-e.maintenance_rx_state_?.performance_penalty>=.3?`#ffaa00`:`#ff0000`,borderRadius:`4px`,transition:`all 0.3s`}})}function ne(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontSize:`1.5rem`,color:1-e.maintenance_rx_state_?.performance_penalty>=.9?`#00ff00`:1-e.maintenance_rx_state_?.performance_penalty>=.7?`#88ff00`:1-e.maintenance_rx_state_?.performance_penalty>=.5?`#ffff00`:1-e.maintenance_rx_state_?.performance_penalty>=.3?`#ffaa00`:`#ff0000`,fontWeight:`bold`}},((1-e.maintenance_rx_state_?.performance_penalty)*100).toLocaleString(`en-US`,(e=>({minimumFractionDigits:e,maximumFractionDigits:e}))(1)).replaceAll(`,`,``)+`%`)}function re(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(c,{color:1-e.maintenance_rx_state_?.performance_penalty>=.9?`green`:`red`,size:`2`},1-e.maintenance_rx_state_?.performance_penalty>=.9?`OPTIMAL`:1-e.maintenance_rx_state_?.performance_penalty>=.7?`GOOD`:1-e.maintenance_rx_state_?.performance_penalty>=.5?`DEGRADED`:1-e.maintenance_rx_state_?.performance_penalty>=.3?`POOR`:`CRITICAL`)}function ie(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(p,{css:{maxWidth:`400px`},gap:`1`,wrap:`wrap`},Array.prototype.map.call(e.maintenance_rx_state_?.tubes.slice(void 0,8)??[],(e,t)=>h(i,{css:{width:`40px`,height:`40px`,display:`flex`,alignItems:`center`,justifyContent:`center`,background:e?.status?.valueOf?.()===`failed`?.valueOf?.()?`#330000`:e?.status?.valueOf?.()===`degrading`?.valueOf?.()?`#332200`:e?.status?.valueOf?.()===`warming_up`?.valueOf?.()?`#001133`:`#003300`,border:`2px solid `+(e?.status?.valueOf?.()===`failed`?.valueOf?.()?`#ff0000`:e?.status?.valueOf?.()===`degrading`?.valueOf?.()?`#ffaa00`:e?.status?.valueOf?.()===`warming_up`?.valueOf?.()?`#0088ff`:`#00ff00`),borderRadius:`4px`,cursor:e?.status?.valueOf?.()===`failed`?.valueOf?.()||e?.status?.valueOf?.()===`degrading`?.valueOf?.()?`pointer`:`default`,transition:`all 0.2s`,animation:e?.status?.valueOf?.()===`failed`?.valueOf?.()?`blink 0.5s infinite`:e?.status?.valueOf?.()===`degrading`?.valueOf?.()?`pulse 2s infinite`:e?.status?.valueOf?.()===`warming_up`?.valueOf?.()?`glow 1s infinite`:`none`},key:t},h(a,{as:`p`,css:{fontSize:`1.2rem`,color:e?.status?.valueOf?.()===`failed`?.valueOf?.()?`#ff0000`:e?.status?.valueOf?.()===`degrading`?.valueOf?.()?`#ffaa00`:e?.status?.valueOf?.()===`warming_up`?.valueOf?.()?`#0088ff`:`#00ff00`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontWeight:`bold`}},e?.status?.valueOf?.()===`failed`?.valueOf?.()?`✗`:e?.status?.valueOf?.()===`degrading`?.valueOf?.()?`▒`:e?.status?.valueOf?.()===`warming_up`?.valueOf?.()?`◌`:`▓`))))}function ae(){return h(g.Fragment,{},(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state).tutorial_active_rx_state_?h(g.Fragment,{},h(i,{css:{padding:`0.75rem`,background:`#001100`,border:`1px solid #00ff00`,borderRadius:`4px`,cursor:`pointer`,"&:hover":{background:`#002200`,borderColor:`#00ff00`}}},h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`row`,gap:`2`},h(i,{css:{width:`30px`,height:`30px`,display:`flex`,alignItems:`center`,justifyContent:`center`,background:`#003300`,border:`2px solid #00ff00`,borderRadius:`50%`}},h(a,{as:`p`,css:{fontSize:`1.5rem`,fontWeight:`bold`,color:`#00ff00`}},`?`)),h(p,{align:`start`,className:`rx-Stack`,css:{alignItems:`start`},direction:`column`,gap:`0`},h(a,{as:`p`,css:{fontSize:`0.75rem`,color:`#888888`,textTransform:`uppercase`}},`TRAINING MISSION 1`),h(a,{as:`p`,css:{fontSize:`0.9rem`,color:`#00ff00`,fontWeight:`bold`}},`Click POWER ON to start the computer`))))):h(g.Fragment,{}))}function oe(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(c,{color:e.cpu_trace_rx_state_?.status?.valueOf?.()===`Done`?.valueOf?.()?`green`:`yellow`},e.cpu_trace_rx_state_?.status)}function se(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`column`,gap:`0`},Array.prototype.map.call(e.cpu_trace_rx_state_?.steps??[],(e,t)=>h(i,{css:{paddingTop:`0.5rem`,paddingBottom:`0.5rem`,borderBottom:`1px solid #003300`,"&:hover":{background:`#001100`}},key:t},h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`row`,gap:`2`},h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,color:`#00ff00`,width:`40px`,fontSize:`0.9rem`}},`#`+e?.step_number),h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,color:`#88ff88`,flex:`1`,fontSize:`0.9rem`}},e?.instruction)),h(i,{css:{paddingTop:`0.25rem`,paddingBottom:`0.25rem`}},h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,color:`#ffff88`,fontSize:`0.85rem`,paddingLeft:`50px`}},`→ `+e?.description)))))}function ce(){return h(g.Fragment,{},(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state).cpu_trace_rx_state_?.steps.length>0?h(g.Fragment,{},h(se,{})):h(g.Fragment,{},h(a,{as:`p`,css:{color:`#888888`}},`Idle`)))}function le(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(a,{as:`p`,css:{color:`#ffff00`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`}},`Result: `+e.cpu_trace_rx_state_?.final_result)}function ue(){return h(g.Fragment,{},(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state).cpu_trace_rx_state_?.status?.valueOf?.()===`Done`?.valueOf?.()?h(g.Fragment,{},h(le,{})):h(g.Fragment,{},h(i,{})))}function de(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,color:`#ffff00`,fontSize:`1.2rem`}},e.selected_track_rx_state_?.id)}function fe(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(c,{color:e.selected_track_rx_state_?.track_type?.valueOf?.()===`hostile`?.valueOf?.()?`red`:`green`,css:{fontSize:`0.9rem`}},e.selected_track_rx_state_?.track_type.toUpperCase())}function pe(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,color:`#88ff88`,fontSize:`1.1rem`}},e.selected_track_rx_state_?.altitude.toLocaleString(`en-US`).replaceAll(`,`,`,`)+` ft`)}function $(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,color:`#88ff88`,fontSize:`1.1rem`}},e.selected_track_rx_state_?.speed.toLocaleString(`en-US`,(e=>({minimumFractionDigits:e,maximumFractionDigits:e}))(0)).replaceAll(`,`,``)+` kts`)}function me(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,color:`#88ff88`,fontSize:`1.1rem`}},e.selected_track_rx_state_?.heading.toLocaleString(`en-US`,(e=>({minimumFractionDigits:e,maximumFractionDigits:e}))(0)).replaceAll(`,`,``)+`°`)}function he(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(c,{color:(()=>{switch(JSON.stringify(e.selected_track_rx_state_?.threat_level)){case JSON.stringify(`CRITICAL`):return`red`;case JSON.stringify(`HIGH`):return`red`;default:return`yellow`}})(),css:{fontSize:`0.9rem`}},e.selected_track_rx_state_?.threat_level)}function ge(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,color:`#88ff88`,fontSize:`0.9rem`}},`X: `+e.selected_track_rx_state_?.x.toLocaleString(`en-US`,(e=>({minimumFractionDigits:e,maximumFractionDigits:e}))(3)).replaceAll(`,`,``)+`  Y: `+e.selected_track_rx_state_?.y.toLocaleString(`en-US`,(e=>({minimumFractionDigits:e,maximumFractionDigits:e}))(3)).replaceAll(`,`,``))}function _e(){let e=(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state);return h(a,{as:`p`,css:{color:e.lightgun_armed_rx_state_?`#ffff00`:`#888888`,fontSize:`0.9rem`,textAlign:`center`,fontStyle:`italic`}},e.lightgun_armed_rx_state_?`LIGHT GUN ARMED - SELECT TARGET`:`NO TARGET SELECTED`)}function ve(){return h(g.Fragment,{},(0,g.useContext)(s.reflex___state____state__an_fsq7_simulator___interactive_sage____interactive_sage_state).selected_track_rx_state_?.valueOf?.()===null?.valueOf?.()?h(g.Fragment,{},h(i,{css:{padding:`1rem`,background:`#000000`,border:`1px solid #00ff00`,borderRadius:`4px`}},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`},size:`4`},`TARGET DETAIL`),h(i,{css:{padding:`2rem`,border:`1px dashed #003300`,borderRadius:`4px`}},h(_e,{})))):h(g.Fragment,{},h(i,{css:{padding:`1rem`,background:`#000000`,border:`2px solid #00ff00`,borderRadius:`4px`}},h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`,marginBottom:`1rem`},direction:`row`,justify:`between`,gap:`3`},h(o,{css:{color:`#00ff00`},size:`4`},`TARGET DETAIL`),h(c,{color:`green`},`SELECTED`)),h(i,{css:{spacing:`3`,marginBottom:`1rem`}},h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`2`},h(a,{as:`p`,css:{fontWeight:`bold`,color:`#00ff00`,width:`60px`}},`ID:`),h(de,{})),h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`2`},h(a,{as:`p`,css:{fontWeight:`bold`,color:`#00ff00`,width:`60px`}},`TYPE:`),h(fe,{}))),h(r,{columns:`2`,css:{marginBottom:`1rem`},gap:`4`},h(i,{},h(a,{as:`p`,css:{fontSize:`0.8rem`,color:`#888888`}},`ALTITUDE`),h(pe,{})),h(i,{},h(a,{as:`p`,css:{fontSize:`0.8rem`,color:`#888888`}},`SPEED`),h($,{})),h(i,{},h(a,{as:`p`,css:{fontSize:`0.8rem`,color:`#888888`}},`HEADING`),h(me,{})),h(i,{},h(a,{as:`p`,css:{fontSize:`0.8rem`,color:`#888888`}},`THREAT`),h(he,{}))),h(i,{css:{marginBottom:`1rem`}},h(a,{as:`p`,css:{fontSize:`0.8rem`,color:`#888888`,marginBottom:`0.25rem`}},`POSITION`),h(ge,{})),h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`column`,gap:`2`},h(d,{css:{background:`#003300`,color:`#00ff00`,border:`2px solid #00ff00`,width:`100%`,"&:hover":{background:`#005500`}},size:`3`},`🚀 LAUNCH INTERCEPT`),h(d,{css:{background:`#330000`,color:`#ff0000`,border:`1px solid #ff0000`,width:`100%`,"&:hover":{background:`#550000`}},size:`2`},`✕ CLEAR SELECTION`)))))}var ye=t(function(){return h(g.Fragment,{},h(ee,{css:{padding:`16px`,maxWidth:`100%`,background:`#000000`},size:`3`},h(p,{align:`start`,className:`rx-Stack`,css:{padding:`20px`},direction:`column`,gap:`5`},h(o,{css:{color:`#00ff00`},size:`9`},`AN/FSQ-7 SAGE Simulator`),h(a,{as:`p`,css:{color:`#88ff88`}},`Interactive Cold War Air Defense System`),h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`5`},h(p,{align:`start`,className:`rx-Stack`,css:{width:`300px`},direction:`column`,gap:`4`},h(i,{css:{padding:`1.5rem`,background:`#000000`,border:`2px solid #00ff00`,borderRadius:`8px`,maxHeight:`100vh`,overflowY:`auto`}},h(o,{css:{color:`#00ff00`,marginBottom:`1rem`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`},size:`5`},`SD CONSOLE CONTROLS`),h(i,{css:{padding:`0.75rem`,background:`#001100`,border:`1px solid #003300`,borderRadius:`4px`,marginBottom:`1rem`}},h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`row`,gap:`4`},h(i,{},h(a,{as:`p`,css:{fontWeight:`bold`,color:`#00ff00`,fontSize:`0.8rem`}},`ACTIVE FILTERS:`),h(_,{})),h(f,{css:{height:`30px`},orientation:`vertical`,size:`4`}),h(i,{},h(a,{as:`p`,css:{fontWeight:`bold`,color:`#00ff00`,fontSize:`0.8rem`}},`ACTIVE OVERLAYS:`),h(v,{})))),h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`column`,gap:`4`},h(i,{css:{padding:`1rem`,background:`#000000`,border:`1px solid #00ff00`,borderRadius:`4px`}},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`},size:`3`},`CATEGORY SELECT (S1-S13)`),h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.8rem`,marginBottom:`0.75rem`}},`Filter radar display by track type`),h(r,{columns:`2`,css:{width:`100%`},gap:`2`},h(y,{}),h(b,{}),h(x,{}),h(S,{}),h(C,{}),h(w,{}),h(T,{}),h(E,{}),h(D,{}),h(O,{}),h(k,{}),h(A,{}),h(j,{}))),h(i,{css:{padding:`1rem`,background:`#000000`,border:`1px solid #00ff00`,borderRadius:`4px`}},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`},size:`3`},`FEATURE SELECT (S20-S24)`),h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.8rem`,marginBottom:`0.75rem`}},`Toggle display overlays`),h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`column`,gap:`3`},h(i,{},h(M,{}),h(a,{as:`p`,css:{color:`#666666`,fontSize:`0.75rem`,marginTop:`0.25rem`,fontStyle:`italic`}},`Show trailing paths behind targets`)),h(i,{},h(N,{}),h(a,{as:`p`,css:{color:`#666666`,fontSize:`0.75rem`,marginTop:`0.25rem`,fontStyle:`italic`}},`Show intercept missile vectors`)),h(i,{},h(P,{}),h(a,{as:`p`,css:{color:`#666666`,fontSize:`0.75rem`,marginTop:`0.25rem`,fontStyle:`italic`}},`Show 100/200/300 mile range circles`)),h(i,{},h(F,{}),h(a,{as:`p`,css:{color:`#666666`,fontSize:`0.75rem`,marginTop:`0.25rem`,fontStyle:`italic`}},`Show track ID labels`)),h(i,{},h(I,{}),h(a,{as:`p`,css:{color:`#666666`,fontSize:`0.75rem`,marginTop:`0.25rem`,fontStyle:`italic`}},`Show geographic coastline overlay`)))),h(i,{css:{padding:`1rem`,background:`#000000`,border:`1px solid #00ff00`,borderRadius:`4px`}},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`},size:`3`},`OFF-CENTERING CONTROLS`),h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`column`,gap:`3`},h(i,{},h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.8rem`,marginBottom:`0.5rem`}},`PAN VIEW`),h(r,{columns:`3`,css:{justifyItems:`center`,width:`180px`},gap:`1`},h(i,{}),h(L,{}),h(i,{}),h(R,{}),h(z,{}),h(B,{}),h(i,{}),h(V,{}),h(i,{}))),h(f,{size:`4`}),h(i,{},h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.8rem`,marginBottom:`0.5rem`}},`ZOOM`),h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`2`},h(H,{}),h(U,{}),h(te,{}))),h(f,{size:`4`}),h(i,{},h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.8rem`,marginBottom:`0.5rem`}},`ROTATE`),h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`2`},h(W,{}),h(G,{}),h(K,{}))))),h(i,{css:{padding:`1rem`,background:`#000000`,border:`1px solid #00ff00`,borderRadius:`4px`}},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`},size:`3`},`SCOPE BRIGHTNESS`),h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`column`,gap:`3`},h(q,{}),h(J,{}),h(p,{align:`start`,className:`rx-Stack`,direction:`row`,justify:`center`,gap:`2`},h(Y,{}),h(X,{}),h(Z,{})))))),h(i,{css:{padding:`1.5rem`,background:`#000000`,border:`2px solid #00ff00`,borderRadius:`8px`,maxHeight:`100vh`,overflowY:`auto`}},h(o,{css:{color:`#00ff00`,marginBottom:`1rem`,fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`},size:`5`},`VACUUM TUBE MAINTENANCE`),h(i,{css:{padding:`1rem`,background:`#000000`,border:`1px solid #00ff00`,borderRadius:`4px`}},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`},size:`3`},`SYSTEM PERFORMANCE`),h(i,{css:{width:`100%`,height:`30px`,background:`#111111`,border:`2px solid #003300`,borderRadius:`4px`,overflow:`hidden`,marginBottom:`0.5rem`}},h(Q,{})),h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`row`,justify:`between`,gap:`3`},h(ne,{}),h(re,{}))),h(f,{css:{marginTop:`1rem`,marginBottom:`1rem`},size:`4`}),h(i,{css:{padding:`1rem`,background:`#000000`,border:`1px solid #00ff00`,borderRadius:`4px`}},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`},size:`3`},`TUBE STATUS`),h(r,{columns:`2`,css:{marginBottom:`1rem`},gap:`4`},h(i,{},h(a,{as:`p`,css:{fontSize:`0.8rem`,color:`#888888`}},`OPERATIONAL`),h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontSize:`1.5rem`,color:`#00ff00`,fontWeight:`bold`}},`25000`)),h(i,{},h(a,{as:`p`,css:{fontSize:`0.8rem`,color:`#888888`}},`DEGRADING`),h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontSize:`1.5rem`,color:`#ffaa00`,fontWeight:`bold`}},`0`)),h(i,{},h(a,{as:`p`,css:{fontSize:`0.8rem`,color:`#888888`}},`FAILED`),h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontSize:`1.5rem`,color:`#ff0000`,fontWeight:`bold`}},`0`)),h(i,{},h(a,{as:`p`,css:{fontSize:`0.8rem`,color:`#888888`}},`WARMING UP`),h(a,{as:`p`,css:{fontFamily:`'Courier New', monospace`,"--default-font-family":`'Courier New', monospace`,fontSize:`1.5rem`,color:`#0088ff`,fontWeight:`bold`}},`0`))),h(g.Fragment,{},h(g.Fragment,{},h(i,{}))),h(g.Fragment,{},h(g.Fragment,{},h(i,{})))),h(f,{css:{marginTop:`1rem`,marginBottom:`1rem`},size:`4`}),h(i,{},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`},size:`3`},`TUBE RACK`),h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.85rem`,marginBottom:`0.75rem`}},`Click failed or degrading tubes to replace`),h(ie,{}),h(p,{align:`start`,className:`rx-Stack`,css:{marginTop:`1rem`},direction:`row`,gap:`4`},h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`1`},h(a,{as:`p`,css:{color:`#00ff00`,fontWeight:`bold`}},`▓`),h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.8rem`}},`OK`)),h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`1`},h(a,{as:`p`,css:{color:`#ffaa00`,fontWeight:`bold`}},`▒`),h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.8rem`}},`Degrading`)),h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`1`},h(a,{as:`p`,css:{color:`#ff0000`,fontWeight:`bold`}},`✗`),h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.8rem`}},`Failed`)),h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`1`},h(a,{as:`p`,css:{color:`#0088ff`,fontWeight:`bold`}},`◌`),h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.8rem`}},`Warming`)))))),h(p,{align:`start`,className:`rx-Stack`,css:{width:`820px`},direction:`column`,gap:`4`},h(i,{css:{width:`800px`,height:`800px`,border:`2px solid #00ff00`,borderRadius:`8px`}},h(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
    
<script>
class RadarScope {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.width = this.canvas.width;
        this.height = this.canvas.height;
        
        // State
        this.tracks = [];
        this.overlays = new Set();
        this.geoData = null;
        this.sweepAngle = 0;
        this.brightness = 0.75;
        this.centerX = this.width / 2;
        this.centerY = this.height / 2;
        this.zoom = 1.0;
        this.panX = 0;
        this.panY = 0;
        
        // Trail history (for fading paths)
        this.trailHistory = new Map();  // trackId -> array of {x, y, timestamp}
        this.maxTrailLength = 20;
        this.trailFadeMs = 5000;
        
        // Click handler for light gun
        this.onTrackClick = null;
        this.canvas.addEventListener('click', (e) => this.handleClick(e));
        
        // Start animation loop
        this.lastFrameTime = Date.now();
        requestAnimationFrame(() => this.render());
    }
    
    updateTracks(tracks) {
        this.tracks = tracks;
        
        // Update trail history
        const now = Date.now();
        tracks.forEach(track => {
            if (!this.trailHistory.has(track.id)) {
                this.trailHistory.set(track.id, []);
            }
            
            const trail = this.trailHistory.get(track.id);
            trail.push({
                x: track.x,
                y: track.y,
                timestamp: now
            });
            
            // Remove old trail points
            while (trail.length > this.maxTrailLength || 
                   (trail.length > 0 && now - trail[0].timestamp > this.trailFadeMs)) {
                trail.shift();
            }
        });
    }
    
    updateOverlays(overlays) {
        this.overlays = new Set(overlays);
    }
    
    updateGeoData(geoData) {
        this.geoData = geoData;
    }
    
    setBrightness(brightness) {
        this.brightness = Math.max(0.2, Math.min(1.0, brightness));
    }
    
    setPan(x, y) {
        this.panX = x;
        this.panY = y;
    }
    
    setZoom(zoom) {
        this.zoom = Math.max(0.5, Math.min(3.0, zoom));
    }
    
    handleClick(e) {
        const rect = this.canvas.getBoundingClientRect();
        const clickX = (e.clientX - rect.left) / rect.width;
        const clickY = (e.clientY - rect.top) / rect.height;
        
        // Find nearest track within threshold
        let nearestTrack = null;
        let nearestDist = 0.05;  // 5% of screen
        
        this.tracks.forEach(track => {
            const dx = track.x - clickX;
            const dy = track.y - clickY;
            const dist = Math.sqrt(dx*dx + dy*dy);
            
            if (dist < nearestDist) {
                nearestDist = dist;
                nearestTrack = track;
            }
        });
        
        if (nearestTrack) {
            // Deselect all tracks first
            this.tracks.forEach(t => t.selected = false);
            // Select the clicked track
            nearestTrack.selected = true;
            
            // Call callback if set
            if (this.onTrackClick) {
                this.onTrackClick(nearestTrack);
            }
            
            console.log('Track selected:', nearestTrack.id || nearestTrack.track_id);
        }
    }
    
    render() {
        const now = Date.now();
        const dt = now - this.lastFrameTime;
        this.lastFrameTime = now;
        
        // Clear screen (black background)
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(0, 0, this.width, this.height);
        
        // Update sweep angle (complete rotation every 4 seconds)
        this.sweepAngle = (this.sweepAngle + (dt / 4000) * Math.PI * 2) % (Math.PI * 2);
        
        // Apply transforms
        this.ctx.save();
        this.ctx.translate(this.centerX + this.panX, this.centerY + this.panY);
        this.ctx.scale(this.zoom, this.zoom);
        this.ctx.translate(-this.centerX, -this.centerY);
        
        // 1. Draw geographic overlays
        if (this.geoData) {
            this.drawGeographicOverlays();
        }
        
        // 2. Draw sweep
        this.drawSweep();
        
        // 3. Draw flight trails
        if (this.overlays.has('flight_paths')) {
            this.drawTrails();
        }
        
        // 4. Draw tracks
        this.drawTracks();
        
        // 5. Draw intercept vectors
        if (this.overlays.has('intercept_vectors')) {
            this.drawInterceptVectors();
        }
        
        this.ctx.restore();
        
        // Request next frame
        requestAnimationFrame(() => this.render());
    }
    
    drawSweep() {
        // Rotating sweep line with fade
        const gradient = this.ctx.createRadialGradient(
            this.centerX, this.centerY, 0,
            this.centerX, this.centerY, Math.min(this.width, this.height) / 2
        );
        gradient.addColorStop(0, \`rgba(0, 255, 0, \${0.3 * this.brightness})\`);
        gradient.addColorStop(0.5, \`rgba(0, 255, 0, \${0.1 * this.brightness})\`);
        gradient.addColorStop(1, 'rgba(0, 255, 0, 0)');
        
        this.ctx.save();
        this.ctx.strokeStyle = gradient;
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();
        this.ctx.moveTo(this.centerX, this.centerY);
        const sweepX = this.centerX + Math.cos(this.sweepAngle) * (this.width / 2);
        const sweepY = this.centerY + Math.sin(this.sweepAngle) * (this.height / 2);
        this.ctx.lineTo(sweepX, sweepY);
        this.ctx.stroke();
        this.ctx.restore();
    }
    
    drawTrails() {
        const now = Date.now();
        
        this.trailHistory.forEach((trail, trackId) => {
            if (trail.length < 2) return;
            
            const track = this.tracks.find(t => t.id === trackId);
            if (!track) return;
            
            // Determine trail color based on track type
            let baseColor = this.getTrackColor(track);
            
            this.ctx.save();
            this.ctx.strokeStyle = baseColor;
            this.ctx.lineWidth = 1;
            
            for (let i = 0; i < trail.length - 1; i++) {
                const age = now - trail[i].timestamp;
                const alpha = Math.max(0, 1 - (age / this.trailFadeMs)) * this.brightness * 0.5;
                
                this.ctx.globalAlpha = alpha;
                this.ctx.beginPath();
                this.ctx.moveTo(trail[i].x * this.width, trail[i].y * this.height);
                this.ctx.lineTo(trail[i+1].x * this.width, trail[i+1].y * this.height);
                this.ctx.stroke();
            }
            
            this.ctx.restore();
        });
    }
    
    drawTracks() {
        this.tracks.forEach(track => {
            const x = track.x * this.width;
            const y = track.y * this.height;
            const color = this.getTrackColor(track);
            const isSelected = track.selected || false;
            
            // Draw glow
            this.ctx.save();
            this.ctx.shadowColor = color;
            this.ctx.shadowBlur = isSelected ? 20 : 10;
            this.ctx.fillStyle = color;
            
            // Draw track dot
            this.ctx.globalAlpha = this.brightness;
            this.ctx.beginPath();
            this.ctx.arc(x, y, isSelected ? 8 : 5, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Draw selection ring
            if (isSelected) {
                this.ctx.strokeStyle = color;
                this.ctx.lineWidth = 2;
                this.ctx.globalAlpha = this.brightness * 0.8;
                this.ctx.beginPath();
                this.ctx.arc(x, y, 15, 0, Math.PI * 2);
                this.ctx.stroke();
            }
            
            // Draw callsign/label
            if (this.overlays.has('callsigns')) {
                this.ctx.font = '10px Courier New';
                this.ctx.fillStyle = color;
                this.ctx.globalAlpha = this.brightness * 0.8;
                this.ctx.fillText(track.id, x + 10, y - 5);
            }
            
            this.ctx.restore();
        });
    }
    
    drawInterceptVectors() {
        // Draw lines from interceptors to their targets
        this.tracks.forEach(track => {
            if (track.track_type === 'interceptor' && track.target_id) {
                const target = this.tracks.find(t => t.id === track.target_id);
                if (!target) return;
                
                const x1 = track.x * this.width;
                const y1 = track.y * this.height;
                const x2 = target.x * this.width;
                const y2 = target.y * this.height;
                
                this.ctx.save();
                this.ctx.strokeStyle = '#0088ff';
                this.ctx.lineWidth = 1;
                this.ctx.setLineDash([5, 5]);
                this.ctx.globalAlpha = this.brightness * 0.6;
                this.ctx.beginPath();
                this.ctx.moveTo(x1, y1);
                this.ctx.lineTo(x2, y2);
                this.ctx.stroke();
                this.ctx.restore();
            }
        });
    }
    
    drawGeographicOverlays() {
        if (!this.geoData) return;
        
        const baseAlpha = this.brightness * 0.3;
        
        // Draw coastlines
        if (this.overlays.has('coastlines') && this.geoData.coastlines) {
            this.ctx.save();
            this.ctx.strokeStyle = \`rgba(0, 255, 0, \${baseAlpha})\`;
            this.ctx.lineWidth = 1.5;
            
            this.geoData.coastlines.forEach(coastline => {
                if (coastline.style === 'dashed') {
                    this.ctx.setLineDash([5, 5]);
                } else if (coastline.style === 'dotted') {
                    this.ctx.setLineDash([2, 3]);
                } else {
                    this.ctx.setLineDash([]);
                }
                
                this.ctx.beginPath();
                coastline.points.forEach((point, i) => {
                    const x = point[0] * this.width;
                    const y = point[1] * this.height;
                    if (i === 0) {
                        this.ctx.moveTo(x, y);
                    } else {
                        this.ctx.lineTo(x, y);
                    }
                });
                this.ctx.stroke();
            });
            
            this.ctx.setLineDash([]);
            this.ctx.restore();
        }
        
        // Draw range rings
        if (this.overlays.has('range_rings') && this.geoData.range_rings) {
            this.ctx.save();
            this.ctx.strokeStyle = \`rgba(0, 255, 0, \${baseAlpha * 0.6})\`;
            this.ctx.lineWidth = 1;
            this.ctx.font = '12px Courier New';
            this.ctx.fillStyle = \`rgba(0, 255, 0, \${baseAlpha})\`;
            
            this.geoData.range_rings.forEach(ring => {
                this.ctx.beginPath();
                this.ctx.arc(
                    this.centerX,
                    this.centerY,
                    ring.radius * Math.min(this.width, this.height),
                    0,
                    Math.PI * 2
                );
                this.ctx.stroke();
                
                // Label
                this.ctx.fillText(
                    ring.label,
                    this.centerX + ring.radius * this.width + 5,
                    this.centerY
                );
            });
            
            this.ctx.restore();
        }
        
        // Draw bearing markers (N/E/S/W)
        if (this.geoData.bearing_markers) {
            this.ctx.save();
            this.ctx.fillStyle = \`rgba(0, 255, 0, \${baseAlpha})\`;
            this.ctx.font = 'bold 14px Courier New';
            
            this.geoData.bearing_markers.forEach(marker => {
                this.ctx.fillText(
                    marker.label,
                    marker.x * this.width - 7,
                    marker.y * this.height + 5
                );
            });
            
            this.ctx.restore();
        }
        
        // Draw city labels
        if (this.overlays.has('callsigns') && this.geoData.cities) {
            this.ctx.save();
            this.ctx.fillStyle = \`rgba(0, 255, 0, \${baseAlpha})\`;
            this.ctx.font = '10px Courier New';
            
            this.geoData.cities.forEach(city => {
                const x = city.x * this.width;
                const y = city.y * this.height;
                
                // City dot
                this.ctx.beginPath();
                this.ctx.arc(x, y, 2, 0, Math.PI * 2);
                this.ctx.fill();
                
                // Label
                this.ctx.fillText(city.label, x + 5, y - 5);
            });
            
            this.ctx.restore();
        }
    }
    
    getTrackColor(track) {
        switch(track.track_type) {
            case 'hostile': return '#ff0000';  // Red
            case 'missile': return '#ff00ff';  // Magenta
            case 'friendly': return '#00ff00'; // Green
            case 'interceptor': return '#0088ff'; // Blue
            case 'unknown': return '#ffff00';  // Yellow
            default: return '#888888';         // Gray
        }
    }
}

// Initialize radar scope
let radarScope = null;

function initRadarScope(canvasId) {
    radarScope = new RadarScope(canvasId);
    console.log('Radar scope initialized');
    return radarScope;
}

// Export for use from Python/Reflex
window.radarScope = null;
window.initRadarScope = initRadarScope;

<\/script>

    
<div style="position: relative; width: 100%; height: 100%;">
    <canvas 
        id="radar-scope-canvas" 
        width="800" 
        height="800"
        style="width: 100%; height: 100%; background: #000000; border-radius: 8px;"
    ></canvas>
</div>

    <script>
        // Initialize on load
        window.addEventListener('load', function() {
            setTimeout(() => {
                window.radarScope = initRadarScope('radar-scope-canvas');
            }, 100);
        });
    <\/script>
    `}})),h(ae,{})),h(p,{align:`start`,className:`rx-Stack`,css:{width:`350px`},direction:`column`,gap:`4`},h(i,{css:{padding:`1rem`,background:`#000000`,border:`1px solid #00ff00`,borderRadius:`4px`}},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`},size:`4`},`CPU TRACE`),h(p,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`2`},h(a,{as:`p`,css:{color:`#888888`,fontSize:`0.9rem`}},`Status:`),h(oe,{})),h(i,{css:{maxHeight:`200px`,overflowY:`auto`,background:`#000000`,border:`1px solid #003300`,borderRadius:`4px`,padding:`0.5rem`,marginTop:`0.5rem`,marginBottom:`0.5rem`}},h(ce,{})),h(ue,{})),h(ve,{}),h(i,{css:{padding:`1rem`,background:`#000000`,border:`1px solid #00ff00`,borderRadius:`4px`}},h(o,{css:{color:`#00ff00`,marginBottom:`0.5rem`},size:`4`},`LIGHT GUN`),h(p,{align:`start`,className:`rx-Stack`,css:{width:`100%`},direction:`column`,gap:`3`},h(d,{css:{background:`#003300`,color:`#00ff00`,border:`2px solid #00ff00`,width:`100%`,"&:hover":{background:`#005500`}},size:`3`},`🎯 ARM LIGHT GUN (D)`),h(i,{css:{padding:`0.75rem`,background:`#001100`,border:`1px solid #003300`,borderRadius:`4px`}},h(a,{as:`p`,css:{fontWeight:`bold`,color:`#00ff00`,fontSize:`0.85rem`,marginBottom:`0.25rem`}},`INSTRUCTIONS:`),h(a,{as:`p`,css:{color:`#88ff88`,fontSize:`0.8rem`}},`1. Press 'D' or click ARM button`),h(a,{as:`p`,css:{color:`#88ff88`,fontSize:`0.8rem`}},`2. Crosshair appears over scope`),h(a,{as:`p`,css:{color:`#88ff88`,fontSize:`0.8rem`}},`3. Click on radar target`),h(a,{as:`p`,css:{color:`#88ff88`,fontSize:`0.8rem`}},`4. Target info displays below`))))))),h(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
    <script>
        if (window.radarScope) {
            window.radarScope.updateTracks(EventSpec(event_actions={}, handler=EventHandler(event_actions={}, fn=<function InteractiveSageState.get_tracks_json at 0x000001A7301ECEA0>, state_full_name='reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state'), client_handler_name='', args=()));
            window.radarScope.updateOverlays(EventSpec(event_actions={}, handler=EventHandler(event_actions={}, fn=<function InteractiveSageState.get_overlays_json at 0x000001A7301ECF40>, state_full_name='reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state'), client_handler_name='', args=()));
            window.radarScope.updateGeoData(EventSpec(event_actions={}, handler=EventHandler(event_actions={}, fn=<function InteractiveSageState.get_geo_json at 0x000001A7301ECFE0>, state_full_name='reflex___state____state.an_fsq7_simulator___interactive_sage____interactive_sage_state'), client_handler_name='', args=()));
        }
    <\/script>
    `}}),h(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
<style>
#radar-scope-canvas {
    image-rendering: crisp-edges;
    image-rendering: -moz-crisp-edges;
    image-rendering: -webkit-crisp-edges;
    cursor: crosshair;
}

#radar-scope-canvas:hover {
    box-shadow: 0 0 20px rgba(0, 255, 0, 0.3);
}

/* Crosshair cursor when light gun armed */
.lightgun-armed #radar-scope-canvas {
    cursor: crosshair;
}

/* Animation for track selection pulse */
@keyframes pulse-ring {
    0% { r: 8; opacity: 1; }
    100% { r: 20; opacity: 0; }
}
</style>
`}}),h(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
<style>
@keyframes blink {
    0%, 50% { opacity: 1; }
    51%, 100% { opacity: 0.3; }
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.6; }
}

@keyframes glow {
    0%, 100% { box-shadow: 0 0 5px rgba(0,136,255,0.3); }
    50% { box-shadow: 0 0 15px rgba(0,136,255,0.8); }
}
</style>
`}}),h(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`
<script>
document.addEventListener('keydown', function(e) {
    if (e.key === 'd' || e.key === 'D') {
        // Trigger light gun toggle
        // TODO: Send event to Reflex backend
        console.log('Light gun toggle requested');
    }
    if (e.key === 'Escape') {
        // Clear selection
        // TODO: Send event to Reflex backend
        console.log('Clear selection requested');
    }
});
<\/script>
`}})),h(`title`,{},`AnFsq7Simulator | Index`),h(`meta`,{content:`favicon.ico`,property:`og:image`}))});export{ye as default};